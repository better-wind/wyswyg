js timeline
============

jstween的扩展库,类似于greensock的TimelineLite,不过功能比较简单,方便编写大量基于时间线的jstween
注:本库强依赖jstween
https://github.com/shrekshrek/jstween


API
============

全局方法:  
JTL.create();  
JTL.kill();  

实例方法:  
fromTo();  
from();  
to();  
kill();  
add();  
addLabel();  
removeLabel();  
getLabelTime();  
totalTime();  
play();  
pause();  
seek();  
clear();  
destroy();  



